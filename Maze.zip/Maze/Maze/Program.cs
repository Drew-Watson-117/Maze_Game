﻿
using var game = new Maze.Game1();
game.Run();
